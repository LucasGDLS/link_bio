from enum import Enum


class Font(Enum):
    LOGO= "Comfortaa-Medium"
    DEFAULT = "Poppins-Light"
    TITLE = "Poppins-Bold"